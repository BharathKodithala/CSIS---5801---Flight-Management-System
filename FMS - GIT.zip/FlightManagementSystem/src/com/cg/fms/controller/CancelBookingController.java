package com.cg.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.cg.fms.exceptions.BookingNotFoundException;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.FlightNotFoundException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Booking;

import com.cg.fms.model.ScheduleFlight;
import com.cg.fms.service.BookingService;
import com.cg.fms.service.IBookingService;
import com.cg.fms.service.IPassengerService;
import com.cg.fms.service.IScheduleFlightService;
import com.cg.fms.service.PassengerService;
import com.cg.fms.service.ScheduleFlightService;

@WebServlet("/CancelBookingController")
public class CancelBookingController extends HttpServlet {
	static Logger logger = Logger.getLogger(CancelBookingController.class.getName());

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession();
		IBookingService bookingService = new BookingService();
		IPassengerService passengerService = new PassengerService();
		IScheduleFlightService flightService = new ScheduleFlightService();
		ScheduleFlight flight = null;
		boolean isDeleted = false;
		boolean isCancelled = false;
		int isUpdated = 0;
		int flightNumber = 0;
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		int availableSeats = 0;
		int passengerCount = 0;
		try {
			Booking booking = bookingService.viewBookingDetails(bookingId);
			flightNumber = booking.getFlightNumber();
			passengerCount = booking.getPassengerCount();
			flight = flightService.viewFlightDetails(flightNumber);
			availableSeats = flight.getAvailableSeats();
			isCancelled = bookingService.cancelBooking(bookingId);
			isDeleted = passengerService.deletePassengers(bookingId);
			if (isCancelled && isDeleted) {
				availableSeats = flight.getAvailableSeats();
				availableSeats += (passengerCount);
				isUpdated = flightService.updateAvailableSeats(availableSeats, flightNumber);
				logger.info("Updated seats after cancelling flights:" + isUpdated);
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Your booking has been cancelled!');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				logger.info("Control is directed to userPage.jsp after cancelling flights");

			} else {
				out.println("<script type=\"text/javascript\">");
				out.println("alert('Problem ocuured while cancelling! Try again');");
				out.println("location='userPage.jsp';");
				out.println("</script>");
				logger.info("Problem occurred while cancelling booking");
			}

		} catch (FMSException | FlightNotFoundException | PassengerNotFoundException | BookingNotFoundException e) {
			logger.error("Error while cancelling  bookings", e);
			session.setAttribute("errorMessage", e.getMessage());
			response.sendRedirect("errorPage.jsp");
		}
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

}
