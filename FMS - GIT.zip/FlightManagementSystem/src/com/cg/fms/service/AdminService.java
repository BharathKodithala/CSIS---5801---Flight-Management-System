package com.cg.fms.service;

import java.util.List;
import com.cg.fms.dao.AdminDAO;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;

public class AdminService implements IAdminService {

	IAdminDAO adminDao = new AdminDAO();

	/************************************************
	 * @Description: Admin Login
	 * @arg1: String emailId
	 * @arg2: String password
	 * @returns: int
	 * @Exception: FMSException
	 ************************************************/
	public int adminLogin(String emailId, String password) throws FMSException {
		return adminDao.adminLogin(emailId, password);
	}

	/************************************************
	 * @Description: Method to view all airports
	 * @returns: List airports
	 * @Exception: FMSException
	 ************************************************/
	public List<Airport> viewAirports() throws FMSException {
		return adminDao.viewAirports();
	}

}
