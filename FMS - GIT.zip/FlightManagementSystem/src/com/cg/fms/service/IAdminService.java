package com.cg.fms.service;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;

import java.util.*;

public interface IAdminService {
	
	public int adminLogin(String emailId, String password) throws FMSException;
	
	public List<Airport> viewAirports() throws FMSException;
	
}
