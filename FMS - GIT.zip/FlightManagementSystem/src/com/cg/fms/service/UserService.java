package com.cg.fms.service;

import com.cg.fms.dao.IUserDAO;
import com.cg.fms.dao.UserDAO;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.UserNotFoundException;
import com.cg.fms.model.User;

public class UserService implements IUserService {

	IUserDAO userDao = new UserDAO();
	
	/*********************************************************************
	 @Description : Method to check whether the entered user exists or not
	 @arg1 : String emailId
	 @return : boolean
	 @Exception : FMSException
	 */
	public boolean isUserExists(String emailId) throws UserNotFoundException, FMSException {
		return userDao.isUserExists(emailId);
	}


	/*********************************************************************
	 @Description : Method for the user to create his account
	 @arg1 : User user
	 @return : int
	 @Exception : FMSException
	 */
	public int accountCreation(User user) throws UserNotFoundException, FMSException {
		return userDao.accountCreation(user);
	}

	/*********************************************************************
	 @Description : Method for user to login into the application
	 @arg1 : String emailId
	 @arg2 : String password
	 @return : int 
	 @Exception : FMSException
	 */
	public int userLogin(String emailId, String password) throws UserNotFoundException, FMSException {
		return userDao.userLogin(emailId, password);
	}
	
	
}
