package com.cg.fms.dao;

public interface UserQueryConstants {

	String USER_EXISTS = "select * from user where emailid = ?";
	String REGISTER_USER = "insert into user(username,password,mobileno,emailid)values(?,?,?,?);";
	String USER_LOGIN = "select * from user where emailid=? AND password=? ";
	
}
