package com.cg.fms.dao;

public interface ScheduleFlightQueryConstants {

	String SCHEDULE_FLIGHT = "insert into scheduleflight values(?,?,?,?,?,?,?,?,?,?)";
	String SEARCH_FLIGHT = "select * from scheduleflight where flight_number = ?";
	String VIEW_SCHEDULE_FLIGHTS = "select * from scheduleflight";
	String FLIGHT_EXISTS = "select * from scheduleflight where arrival_date = ? AND departure_date = ? AND flight_number = ?";
	String VIEW_AVAILABLE_FLIGHTS = "select * from scheduleflight where source_airport=? AND destination_airport=? AND available_seats != 0 AND departure_date = ?";
	String VIEW_FLIGHT_DETAILS="select * from  scheduleflight where flight_number=?";
	String UPDATE_AVAILABLE_SEATS = "update scheduleflight set available_seats = ? where flight_number = ?";
}
