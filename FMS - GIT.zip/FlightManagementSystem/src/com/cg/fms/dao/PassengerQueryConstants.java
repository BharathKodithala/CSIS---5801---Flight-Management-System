package com.cg.fms.dao;

public interface PassengerQueryConstants {

	String ADD_PASSENGER = "insert into passenger (passenger_name,passenger_age,aadhar,luggage,userid,passenger_gender,booking_date,bookingId)values(?,?,?,?,?,?,?,?)";
	String DELETE_PASSENGERS = "delete from passenger where bookingId = ?";
	String VIEW_PASSENGER_DETAILS="select * from passenger where bookingId = ?";
	String UPDATE_PASSENGER = "update passenger set passenger_name=?,passenger_age=?,aadhar=?,luggage=?,passenger_gender=? where pnr_no=?";
}
