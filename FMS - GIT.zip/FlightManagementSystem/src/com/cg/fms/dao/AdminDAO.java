package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.utility.JdbcUtility;

public class AdminDAO implements IAdminDAO {
	static Connection connection = null;
	static PreparedStatement preparedStatement = null;
	static ResultSet resultSet = null;
	
	
	public int adminLogin(String emailId, String password) throws FMSException {
		int rows =0;
		try {
				connection = JdbcUtility.getConnection();
				preparedStatement = connection.prepareStatement(AdminQueryConstants.ADMIN_LOGIN);
				preparedStatement.setString(1, emailId);
				preparedStatement.setString(2, password);
				resultSet = preparedStatement.executeQuery();
				while(resultSet.next()) {
					rows = resultSet.getInt(1);
					
				}
			}
			catch(ClassNotFoundException exception) {
				throw new FMSException(exception.getMessage());
			}
			catch(SQLException exception) {
				throw new FMSException(exception.getMessage());
			} finally {
				try {
					connection.close();
				} catch (SQLException exception) {
					throw new FMSException(exception.getMessage());
				}

			}
			return rows;
	}
	
	
	/************************************************
	 @Description: Method to view all airports
	 @returns: List airports
	 @Exception: FMSException
	 ************************************************/
	public List<Airport> viewAirports() throws FMSException {
		List<Airport> airports = new ArrayList<Airport>();
		Airport airport = null;
		try {
			connection = JdbcUtility.getConnection();
			preparedStatement = connection.prepareStatement(AdminQueryConstants.VIEW_AIRPORTS);
			resultSet = preparedStatement.executeQuery();
			while(resultSet.next()) {
				airport = new Airport();
				airport.setAirportCode(resultSet.getString(1));
				airport.setAirportName(resultSet.getString(2));
				airport.setAirportLocation(resultSet.getString(3));
				airports.add(airport);
			}
		} catch(SQLException exception) {
			throw new FMSException(exception.getMessage());
		} catch(ClassNotFoundException exception) {
			throw new FMSException(exception.getMessage());
		} finally {
			try {
				connection.close();
			} catch (SQLException exception) {
				throw new FMSException(exception.getMessage());
			}

		}
		
		return airports;
		
	}
	
}
