package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Passengers;

public interface IPassengerDAO {

	public int addPassengers(Passengers passenger) throws FMSException;
	
	public boolean deletePassengers(int bookingId) throws PassengerNotFoundException, FMSException;
	
	public int modifyPassengers(Passengers passenger) throws PassengerNotFoundException,FMSException;
	
	public List<Passengers> viewPassengerDetails(int bookingId) throws PassengerNotFoundException,FMSException;
}
