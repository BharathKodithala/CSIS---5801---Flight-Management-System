package com.cg.fms.dao;

public interface AdminQueryConstants {
	
	String ADMIN_LOGIN = "select * from user where emailid=? AND password=? ";
	String VIEW_AIRPORTS = "select * from airport";
	
}
