package com.cg.fms.dao;

public interface FlightQueryConstants {

	String ADD_FLIGHT = "insert into flight(flight_model,carrier_name,seat_capacity)values(?,?,?);";
	String VIEW_FLIGHTS = "select * from flight";
	String GET_FLIGHT = "select flight_number from flight where flight_model = ?";
}
