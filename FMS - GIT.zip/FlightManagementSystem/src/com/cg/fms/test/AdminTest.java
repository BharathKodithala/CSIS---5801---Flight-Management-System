package com.cg.fms.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.model.Airport;
import com.cg.fms.service.AdminService;
import com.cg.fms.service.IAdminService;

public class AdminTest {
	IAdminService adminService = new AdminService();
	
	@Test
	public void adminLoginTest() throws FMSException {
		int result1= adminService.adminLogin("admin@gmail.com","Admin24!");
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
		actualResult1 = true;
		} else {
		actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		int result2= adminService.adminLogin("admin@gmail.com","admin");
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
		actualResult2 = true;
		} else {
		actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
		int result3= adminService.adminLogin("sindhura@gmail.com","Admin@123");
		boolean actualResult3;
		boolean expectedResult3;
		if(result3 > 0) {
		actualResult3 = true;
		} else {
		actualResult3 = false;
		}
		expectedResult3 = false;
		assertEquals(expectedResult3,actualResult3);
		
		int result4= adminService.adminLogin("sindhura@gmail.com","Sindhu@123");
		boolean actualResult4;
		boolean expectedResult4;
		if(result4 > 0) {
		actualResult4 = true;
		} else {
		actualResult4 = false;
		}
		expectedResult4 = false;
		assertEquals(expectedResult4,actualResult4);
		
		
	}
	
	@Test
	public void viewAirportsTest() throws FMSException {
	
	List<Airport> result1= adminService.viewAirports();
	boolean actualResult1;
	boolean expectedResult1;
	if(result1.size() !=0) {
	actualResult1 = true;
	} else {
	actualResult1 = false;
	}
	expectedResult1 = true;
	assertEquals(expectedResult1,actualResult1);
	
	}
	
	
}