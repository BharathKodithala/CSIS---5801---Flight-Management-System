package com.cg.fms.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Test;

import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.PassengerNotFoundException;
import com.cg.fms.model.Passengers;
import com.cg.fms.service.IPassengerService;
import com.cg.fms.service.PassengerService;

public class PassengerTest {
	
	IPassengerService passengerService = new PassengerService();
	@Test
	public void addPassengerTest() throws FMSException {
		Passengers passenger1 = new Passengers("Bindhu",21,987651234,2,"Female",1,"2020-10-21",1);
		int result1= passengerService.addPassengers(passenger1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		Passengers passenger2 = null;
		int result2= passengerService.addPassengers(passenger2);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
	}
	
	@Test
	public void deletePassengersTest() throws FMSException, PassengerNotFoundException {
	
		boolean result1= passengerService.deletePassengers(1);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 == true) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		boolean result2= passengerService.deletePassengers(0);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 == true) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2); 
	
	
	}
	@Test
	public void modifyPassengersTest() throws FMSException, PassengerNotFoundException {
		Passengers passenger1 = new Passengers(4,"Akshitha",21,45625864,1,"Female");
		 int result1= passengerService.modifyPassengers(passenger1);
		 boolean actualResult1;
		 boolean expectedResult1;
			if(result1 > 0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			
			Passengers passenger2 = new Passengers();
			int result2= passengerService.modifyPassengers(passenger2);
			boolean actualResult2;
			boolean expectedResult2;
			if(result2 > 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
		
	}
	
	@Test
	public void viewPassengerDetailsTest() throws FMSException, PassengerNotFoundException {
		
		 List<Passengers> result1= passengerService.viewPassengerDetails(1);
		 boolean actualResult1;
			boolean expectedResult1;
			if(result1.size() !=0) {
				actualResult1 = true;
			} else {
				actualResult1 = false;
			}
			expectedResult1 = true;
			assertEquals(expectedResult1,actualResult1);
			
			
			
			 List<Passengers> result2= passengerService.viewPassengerDetails(0);
			boolean actualResult2;
			boolean expectedResult2;
			if( result2.size()!= 0) {
				actualResult2 = true;
			} else {
				actualResult2 = false;
			}
			expectedResult2 = false;
			assertEquals(expectedResult2,actualResult2);
		
	
	}
}
