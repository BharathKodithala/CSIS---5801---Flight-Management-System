package com.cg.fms.test;

import static org.junit.Assert.*;
import org.junit.Test;
import com.cg.fms.exceptions.FMSException;
import com.cg.fms.exceptions.UserNotFoundException;
import com.cg.fms.model.User;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserService;

public class UserTest {
   IUserService userService = new UserService();
	@Test
	public void isUserExistsTest() throws UserNotFoundException, FMSException{
		boolean actualResult1= userService.isUserExists("akshitha1234@gmail.com");
		boolean expectedResult1 =true;
		assertEquals(expectedResult1,actualResult1);
		
		
		boolean actualResult2= userService.isUserExists("sarah@gmail.com");
		boolean expectedResult2 =false;
		assertEquals(expectedResult2,actualResult2);
		
	}
	@Test
	public void accountCreationTest() throws UserNotFoundException, FMSException {
		User user = new User("DarlingPrabhas","Sharmila45!",912345678,"Pandu12345@gmail.com");
		int result1= userService.accountCreation(user);
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		User user1 = null;
		int result2 = userService.accountCreation(user1);
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
				
	}
	
	@Test
	public void userLoginTest() throws UserNotFoundException, FMSException {
		int result1= userService.userLogin("akshitha1234@gmail.com","Akshitha25!");
		boolean actualResult1;
		boolean expectedResult1;
		if(result1 > 0) {
			actualResult1 = true;
		} else {
			actualResult1 = false;
		}
		expectedResult1 = true;
		assertEquals(expectedResult1,actualResult1);
		
		
		
		int result2= userService.userLogin("sindhura@gmail.com","Sindhura");
		boolean actualResult2;
		boolean expectedResult2;
		if(result2 > 0) {
			actualResult2 = true;
		} else {
			actualResult2 = false;
		}
		expectedResult2 = false;
		assertEquals(expectedResult2,actualResult2);
		
	}
	
}
